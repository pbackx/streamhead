CREATE TABLE `str_spymessage_messages` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY ,
    `message` TEXT NOT NULL ,
    `author_id` INT UNSIGNED NOT NULL
);