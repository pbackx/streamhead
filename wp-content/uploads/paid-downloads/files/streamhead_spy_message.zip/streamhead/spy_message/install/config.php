<?
/* copyright 2012 Streamhead.com */

$aConfig = array(
	'title' => 'Spy Messages', 
    'version' => '1.0.0',
	'vendor' => 'Streamhead.com',
	'update_url' => '',
	
	'compatible_with' => array(
        '7.0.x'
    ),

	'home_dir' => 'streamhead/spy_message/', 
	'home_uri' => 'spymessage', 
	
	'db_prefix' => 'str_spymessage_', 
    'class_prefix' => 'StrSpyMessage', 

	'install' => array(
        'update_languages' => 1, 
        'execute_sql' => 1,
        'recompile_alerts' => 1, // We add new alerts, so recompilation is vital
        'clear_db_cache' => 1,
	),
	'uninstall' => array (
        'update_languages' => 1,
        'execute_sql' => 1,
        'recompile_alerts' => 1,
        'clear_db_cache' => 1,
    ),

	'language_category' => 'Spy Message',

	'install_permissions' => array(),
    'uninstall_permissions' => array(),

	'install_info' => array(
		'introduction' => '',
		'conclusion' => ''
	),
	'uninstall_info' => array(
		'introduction' => '',
		'conclusion' => ''
	)
);

?>
