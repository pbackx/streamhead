<?php

/* copyright 2012 Streamhead.com */

bx_import("BxDolInstaller");

class StrSpyMessageInstaller extends BxDolInstaller {
    function StrSpyMessageInstaller($aConfig) {
        parent::BxDolInstaller($aConfig);
    }

    /* install the handlers responsible for creating the spy message */
    function install($aParams) {
        $aResult = parent::install($aParams);
        if($aResult['result'] && BxDolRequest::serviceExists('spy', 'update_handlers')) {
        	// first, we check whether spy is enabled or not
            BxDolService::call('spy', 'update_handlers', array($this->_aConfig['home_uri'], true));
       }
        return $aResult;
    }

    /* uninstall the handlers */
    function uninstall($aParams) {
        if(BxDolRequest::serviceExists('spy', 'update_handlers')) {
            BxDolService::call('spy', 'update_handlers', array($this->_aConfig['home_uri'], false));
        }
        return parent::uninstall($aParams);
    }    
}

?>
