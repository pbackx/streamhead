<?
/* copyright 2012 Streamhead.com */

$sLangCategory = 'Spy Message';

$aLangContent = array(

    '_str_spymessage' => 'Send Spy Messages',

);

?>
