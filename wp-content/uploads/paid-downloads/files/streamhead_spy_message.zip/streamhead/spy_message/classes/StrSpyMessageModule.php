<?php
/* copyright 2012 Streamhead.com */

bx_import('BxDolModule');

class StrSpyMessageModule extends BxDolModule {

    function PtdSrvysModule(&$aModule) {        
        parent::BxDolModule($aModule);
    }

    function actionHome () {
        $this->_oTemplate->pageStart();

        if (!$GLOBALS['logged']['member'] && !$GLOBALS['logged']['admin']) { // check access to the page
            $this->_oTemplate->displayAccessDenied ();
            return;
        }

        $aVars = array (
            'message' => "Welcome.",
        );

        if(isset($_POST['message'])) { 
            // this is just to demonstrate the spy module integration, not to demonstrate proper Internet security techniques
            $authorId         = $_COOKIE['memberID'];
            $id               = $this->_oDb->storeMessage($_POST['message'], $authorId);
            $aVars['message'] = "Your message was stored with id $id";

            // Now we sent the alert that will eventually be processed by the spy module
            // The names must match whatever you enter in the serviceGetSpyData function below.
            bx_import('BxDolAlerts');
            $oZ = new BxDolAlerts('str_spymessage_messages', 'sent_message', $id, $authorId);
            $oZ->alert();
        }

        echo $this->_oTemplate->parseHtmlByName('home', $aVars);

        $this->_oTemplate->pageCode(_t('_str_spymessage'), true);
    }

    /* This service will tell the Spy module what kind of alerts we intent to send.
        If you change it, you must reinstall the module because it is only read during installation. */
    function serviceGetSpyData() {
        return array(
            'handlers' => array(
                array('alert_unit' => 'str_spymessage_messages', 'alert_action' => 'sent_message', 'module_uri' => 'spymessage', 'module_class' => 'Module', 'module_method' => 'get_spy_post')
            ),
            'alerts' => array(
                array('unit' => 'str_spymessage_messages', 'action' => 'sent_message')
            )
        );
    }

    /* This service will create the actual message that is posted on the Spy wall */
    function serviceGetSpyPost($action, $messageId, $authorId) {
        $spyPost = array();
        $message = $this->_oDb->getMessage($messageId);
        switch($action) {
            case 'sent_message' :
                $spyPost = array(
                    'lang_key' => $message["message"] . " by " . getNickName($authorId)
                );
                break;
            // You could put other actions here if your module has more
        }
        return $spyPost;
    }
}

?>
