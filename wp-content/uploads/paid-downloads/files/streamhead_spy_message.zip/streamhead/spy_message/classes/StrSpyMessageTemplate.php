<?
/* copyright 2012 Streamhead.com */

bx_import ('BxDolTwigTemplate');

class StrSpyMessageTemplate extends BxDolTwigTemplate {
    
	function StrSpyMessageTemplate(&$oConfig, &$oDb) {
	    parent::BxDolTwigTemplate($oConfig, $oDb);
    }
}

?>
