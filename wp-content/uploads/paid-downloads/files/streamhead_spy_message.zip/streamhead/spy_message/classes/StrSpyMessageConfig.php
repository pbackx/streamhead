<?
/* copyright 2012 Streamhead.com */

bx_import('BxDolConfig');

class StrSpyMessageConfig extends BxDolConfig {

	function StrSpyMessageConfig($aModule) {
	    parent::BxDolConfig($aModule);
	}

}

?>
