<?

/* copyright 2012 Streamhead.com */

bx_import('BxDolModuleDb');

class StrSpyMessageDb extends BxDolModuleDb {

	function StrSpyMessageDb(&$oConfig) {
		parent::BxDolModuleDb();
        $this->_sPrefix = $oConfig->getDbPrefix();
    }

    function storeMessage($message, $authorId) {
        $this->query( "INSERT INTO `str_spymessage_messages` SET
                            `message` = '$message',
                            `author_id` = '$authorId'");
        return $this->lastId();
    }

    function getMessage($messageId) {
        return $this->getRow("SELECT * FROM `str_spymessage_messages` WHERE `id` = $messageId");
    }
}
?>
