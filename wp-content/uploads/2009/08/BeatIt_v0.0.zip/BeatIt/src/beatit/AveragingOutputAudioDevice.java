/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * 2009 http://www.streamhead.com
 */
package beatit;

import java.util.logging.Level;
import java.util.logging.Logger;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.AudioDeviceBase;

/**
 * @author Peter Backx
 */
public class AveragingOutputAudioDevice extends AudioDeviceBase {

    private Logger log = Logger.getLogger(AveragingOutputAudioDevice.class.getName());

    private int position = 0;
    private int freq;
    private int channels;
    private int samplesPerMillisecond;
    private boolean init = false;

    private BufferProcessor processor;

    public AveragingOutputAudioDevice(BufferProcessor processor) {
        this.processor = processor;
    }

    @Override
    protected void openImpl() throws JavaLayerException {
        super.openImpl();
    }

    @Override
    protected void writeImpl(short[] samples, int offs, int len) throws JavaLayerException {
        if(!init)
        {
            log.log(Level.INFO, "number of channels: " + getDecoder().getOutputChannels());
            log.log(Level.INFO, "number of samples: " + getDecoder().getOutputFrequency());
            freq = getDecoder().getOutputFrequency();
            channels = getDecoder().getOutputChannels();
            samplesPerMillisecond = (freq * channels)/1000;
            log.log(Level.INFO, "samples/ms: " + samplesPerMillisecond);
            log.log(Level.INFO, "buffer length: " + len);
            init = true;
        }
        position += len/samplesPerMillisecond;

        if(processor != null)
        {
            long average = 0;
            for(short s : samples)
                average += s;
            short[] a = new short[] { (short)(average/len) } ;
            processor.process(a);
        }
    }

    /**
     * Retrieves the current playback position in milliseconds.
    */
    public int getPosition() {
        log.log(Level.FINE, "position: " + position + "ms");
        return position;
    }

    public BufferProcessor getProcessor() {
        return processor;
    }

    public void setProcessor(BufferProcessor processor) {
        this.processor = processor;
    }
}
