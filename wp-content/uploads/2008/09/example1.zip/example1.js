
Ext.BLANK_IMAGE_URL = './ext-2.1/resources/images/default/s.gif';

Ext.namespace('example1');

example1.recipes = function() {

  var deliciousStore;
  var recipesGrid;

  return {
    init : function() {
      deliciousStore = new Ext.data.Store({
        proxy: new Ext.data.ScriptTagProxy({
          url : 'http://feeds.delicious.com/v2/json/pbackx/recipes'
        }),
        reader: new Ext.data.JsonReader({
          }, Ext.data.Record.create([
              { name : 'url',   mapping : 'u' },
              { name : 'title', mapping : 'd' },
              { name : 'description', mapping : 'n'}
          ])
        )
      });
  
      deliciousStore.load();
  
      recipesGrid = new Ext.grid.GridPanel({
        height:300,
        width:300,
        title:'recipes',
        store: deliciousStore,
        cm: new Ext.grid.ColumnModel([{
          header: 'Link',
          dataIndex: 'url',
        },{
          header: 'Recipe name',
          dataIndex: 'title',
        }])
      });

      recipesGrid.render('recipeContent');
    } // end of init
  }
}();

example1.app = function() {
  return {
    init: function() {
      example1.recipes.init();
    }
  };
}();

Ext.onReady(example1.app.init, example1.app);